# Zegar Trzeźwości 2.0

Polskojęzyczna aplikacja Android do śledzenia własnych okresów trzeźwości i zmian nawyków.

## Funkcje
- pięć niezależnych liczników z datą startu
- zmiana daty startu i rozpoczęcie nowego okresu
- rekord najlepszego okresu oraz kamienie milowe 1, 7, 30, 100 i 365 dni
- dziennik samopoczucia z notatkami
- szacowanie oszczędności po ustawieniu dziennego kosztu
- lokalny zapis danych bez konta

## Budowanie
Wymaga JDK 17, Android SDK i Gradle 8.9:
`gradle assembleDebug`

APK: `app/build/outputs/apk/debug/app-debug.apk`
