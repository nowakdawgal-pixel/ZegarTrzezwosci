package pl.zegartrzezwosci.app

import android.app.DatePickerDialog
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.max

private val Bg = Color(0xFF0B1512)
private val Surface = Color(0xFF14231D)
private val Green = Color(0xFF69D6A0)
private val Muted = Color(0xFFA9BDB2)
private val White = Color(0xFFF2F8F4)

data class Habit(
    val id: String,
    val title: String,
    val emoji: String,
    val start: Long,
    val enabled: Boolean = true,
    val dailyCost: Int = 0,
    val bestSeconds: Long = 0
)

data class MoodEntry(val date: Long, val mood: Int, val note: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ZegarApp() }
    }
}

@Composable
fun ZegarApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("zegar_trzezwosci_v2", 0) }
    fun loadHabits(): MutableList<Habit> {
        val arr = runCatching { JSONArray(prefs.getString("habits", "[]")) }.getOrElse { JSONArray() }
        val out = mutableListOf<Habit>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(Habit(o.optString("id"), o.optString("title"), o.optString("emoji", "🌱"),
                o.optLong("start", System.currentTimeMillis()), o.optBoolean("enabled", true),
                o.optInt("cost", 0), o.optLong("best", 0)))
        }
        if (out.isEmpty()) {
            listOf(
                Habit("crystal", "Kryształ", "💎", System.currentTimeMillis()),
                Habit("amphetamine", "Amfetamina", "⚡", System.currentTimeMillis()),
                Habit("weed", "Zioło", "🌿", System.currentTimeMillis()),
                Habit("alcohol", "Alkohol", "🥤", System.currentTimeMillis(), dailyCost = 0),
                Habit("nicotine", "Papierosy / e-papierosy", "🚭", System.currentTimeMillis(), dailyCost = 0)
            ).also { out.addAll(it); saveHabits(prefs, it) }
        }
        return out
    }
    var habits by remember { mutableStateOf(loadHabits()) }
    var tab by remember { mutableStateOf("home") }
    var mood by remember { mutableIntStateOf(3) }
    var note by remember { mutableStateOf("") }
    var refresh by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(1000)
            refresh = System.currentTimeMillis()
        }
    }
    fun update(newList: List<Habit>) {
        habits = newList.toMutableList()
        saveHabits(prefs, newList)
    }
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Green, onPrimary = Bg, background = Bg, onBackground = White,
        surface = Surface, onSurface = White, secondary = Muted
    )) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                Row(
                    modifier = Modifier.fillMaxWidth().background(Surface),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    NavItem("home", "Start", Icons.Default.Home, tab) { tab = it }
                    NavItem("stats", "Postępy", Icons.Default.Insights, tab) { tab = it }
                    NavItem("mood", "Dziennik", Icons.Default.MenuBook, tab) { tab = it }
                    NavItem("settings", "Ustawienia", Icons.Default.Settings, tab) { tab = it }
                }
            }
        ) { padding ->
            when (tab) {
                "home" -> HomeScreen(habits, refresh, Modifier.padding(padding),
                    onDate = { h -> showDatePicker(context, h.start) { millis ->
                        val elapsed = max(0L, System.currentTimeMillis() - millis) / 1000
                        val best = max(h.bestSeconds, elapsed)
                        update(habits.map { if (it.id == h.id) it.copy(start = millis, bestSeconds = best) else it })
                    } },
                    onReset = { h ->
                        update(habits.map { if (it.id == h.id) it.copy(bestSeconds = max(it.bestSeconds, (System.currentTimeMillis()-it.start)/1000), start = System.currentTimeMillis()) else it })
                    })
                "stats" -> StatsScreen(habits, refresh, Modifier.padding(padding))
                "mood" -> MoodScreen(prefs, Modifier.padding(padding))
                else -> SettingsScreen(habits, Modifier.padding(padding), onCost = { h, cost ->
                    update(habits.map { if (it.id == h.id) it.copy(dailyCost = cost) else it })
                }, onEnabled = { h, enabled ->
                    update(habits.map { if (it.id == h.id) it.copy(enabled = enabled) else it })
                })
            }
        }
    }
}

private fun saveHabits(prefs: android.content.SharedPreferences, habits: List<Habit>) {
    val arr = JSONArray()
    habits.forEach { h ->
        arr.put(JSONObject().put("id", h.id).put("title", h.title).put("emoji", h.emoji)
            .put("start", h.start).put("enabled", h.enabled).put("cost", h.dailyCost).put("best", h.bestSeconds))
    }
    prefs.edit().putString("habits", arr.toString()).apply()
}

@Composable
fun RowScope.NavItem(id: String, label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: String, onSelect: (String) -> Unit) {
    Column(
        modifier = Modifier
            .weight(1f)
            .clickable { onSelect(id) }
            .padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = label, tint = if (selected == id) Green else Muted)
        Text(label, color = if (selected == id) Green else Muted, fontSize = 11.sp)
    }
}

@Composable
fun HomeScreen(habits: List<Habit>, now: Long, modifier: Modifier, onDate: (Habit) -> Unit, onReset: (Habit) -> Unit) {
    LazyColumn(modifier.fillMaxSize().padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(top = 20.dp, bottom = 24.dp)) {
        item {
            Text("Zegar Trzeźwości", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = White)
            Text("Każdy dzień to krok naprzód.", color = Muted, fontSize = 15.sp)
            Spacer(Modifier.height(8.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Text("TWÓJ DZISIEJSZY CEL", color = Green, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text("Nie musisz robić wszystkiego naraz.", color = White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    Text("Skup się na kolejnym dobrym kroku.", color = Muted)
                }
            }
        }
        items(habits.filter { it.enabled }, key = { it.id }) { h ->
            val seconds = max(0L, (now - h.start) / 1000)
            val days = seconds / 86400
            val hours = (seconds % 86400) / 3600
            val mins = (seconds % 3600) / 60
            val secs = seconds % 60
            Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(h.emoji, fontSize = 26.sp)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(h.title, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = White)
                            Text(if (days == 1L) "1 dzień bez" else "$days dni bez", color = Muted, fontSize = 13.sp)
                        }
                        Icon(Icons.Default.CheckCircle, null, tint = Green)
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        TimePart(days.toString(), "dni", Modifier.weight(1f))
                        TimePart(hours.toString().padStart(2, '0'), "godz.", Modifier.weight(1f))
                        TimePart(mins.toString().padStart(2, '0'), "min", Modifier.weight(1f))
                        TimePart(secs.toString().padStart(2, '0'), "sek", Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { onDate(h) }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.Edit, null, Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Ustaw datę")
                        }
                        Button(onClick = { onReset(h) }, modifier = Modifier.weight(1f)) {
                            Text("Nowy okres")
                        }
                    }
                }
            }
        }
        item { Text("Twoje tempo. Twoja droga. Bez oceniania.", color = Muted, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) }
    }
}

@Composable
fun TimePart(value: String, label: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Bg, RoundedCornerShape(12.dp)).padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Green)
        Text(label, fontSize = 11.sp, color = Muted)
    }
}

private fun showDatePicker(context: android.content.Context, current: Long, onPick: (Long) -> Unit) {
    val c = Calendar.getInstance().apply { timeInMillis = current }
    DatePickerDialog(context, { _, year, month, day ->
        val picked = Calendar.getInstance().apply {
            set(Calendar.YEAR, year); set(Calendar.MONTH, month); set(Calendar.DAY_OF_MONTH, day)
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        onPick(picked.timeInMillis)
    }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).apply {
        datePicker.maxDate = System.currentTimeMillis()
    }.show()
}

@Composable
fun StatsScreen(habits: List<Habit>, now: Long, modifier: Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Text("Twoje postępy", fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("Małe kroki też się liczą.", color = Muted)
        }
        items(habits) { h ->
            val seconds = max(0L, (now - h.start) / 1000)
            val days = seconds / 86400
            val milestones = listOf(1L, 7L, 30L, 100L, 365L)
            val next = milestones.firstOrNull { it > days }
            Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("${h.emoji}  ${h.title}", fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                    Spacer(Modifier.height(6.dp))
                    Text("Aktualny okres: $days dni", color = Green, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Najlepszy zapisany okres: ${h.bestSeconds / 86400} dni", color = Muted)
                    Text(if (next != null) "Następny kamień milowy: $next dni" else "Rok za Tobą — ogromny krok!", color = Muted)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 10.dp)) {
                        milestones.forEach { m ->
                            Surface(color = if (days >= m) Green.copy(alpha = .18f) else Bg, shape = RoundedCornerShape(8.dp)) {
                                Text(if (days >= m) "✓ $m" else "$m", color = if (days >= m) Green else Muted, modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp), fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Surface)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Ważne", fontWeight = FontWeight.Bold, color = Green)
                    Text("Licznik wspiera monitorowanie postępów, ale nie zastępuje pomocy medycznej. Przy silnych objawach odstawienia alkoholu lub innych substancji skontaktuj się z lekarzem.", color = Muted)
                }
            }
        }
    }
}

@Composable
fun MoodScreen(prefs: android.content.SharedPreferences, modifier: Modifier) {
    var mood by remember { mutableIntStateOf(3) }
    var note by remember { mutableStateOf("") }
    var entries by remember {
        mutableStateOf(runCatching {
            val a = JSONArray(prefs.getString("moods", "[]"))
            (0 until a.length()).mapNotNull { i -> a.optJSONObject(i)?.let { MoodEntry(it.optLong("date"), it.optInt("mood", 3), it.optString("note")) } }.reversed()
        }.getOrElse { emptyList() })
    }
    val faces = listOf("😣", "😕", "😐", "🙂", "😄")
    Column(modifier.fillMaxSize().padding(18.dp)) {
        Text("Dziennik samopoczucia", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("Zapisz, jak się dziś czujesz.", color = Muted)
        Spacer(Modifier.height(18.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("Jak się czujesz?", fontWeight = FontWeight.SemiBold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    faces.forEachIndexed { i, face ->
                        Text(face, fontSize = 30.sp, modifier = Modifier.clickable { mood = i + 1 }.background(if (mood == i + 1) Green.copy(alpha = .18f) else Color.Transparent, RoundedCornerShape(12.dp)).padding(8.dp))
                    }
                }
                OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("Notatka (opcjonalnie)") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
                Spacer(Modifier.height(12.dp))
                Button(onClick = {
                    val newEntry = MoodEntry(System.currentTimeMillis(), mood, note.trim())
                    entries = listOf(newEntry) + entries
                    val arr = JSONArray()
                    entries.forEach { arr.put(JSONObject().put("date", it.date).put("mood", it.mood).put("note", it.note)) }
                    prefs.edit().putString("moods", arr.toString()).apply()
                    note = ""
                }, modifier = Modifier.fillMaxWidth()) { Text("Zapisz wpis") }
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("Ostatnie wpisy", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Spacer(Modifier.height(8.dp))
        if (entries.isEmpty()) Text("Tutaj pojawią się Twoje wpisy.", color = Muted)
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(entries.take(30)) { entry ->
                Card(colors = CardDefaults.cardColors(containerColor = Surface)) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(faces.getOrElse(entry.mood - 1) { "😐" }, fontSize = 26.sp)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("pl", "PL")).format(Date(entry.date)), color = Green)
                            if (entry.note.isNotBlank()) Text(entry.note, color = White)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(habits: List<Habit>, modifier: Modifier, onCost: (Habit, Int) -> Unit, onEnabled: (Habit, Boolean) -> Unit) {
    var editing by remember { mutableStateOf<Habit?>(null) }
    var costText by remember { mutableStateOf("") }
    LazyColumn(modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Text("Ustawienia", fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("Dopasuj liczniki do siebie.", color = Muted)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Oszczędności", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("Ustaw dzienny koszt dla alkoholu i papierosów. Kwoty są orientacyjne.", color = Muted)
                }
            }
        }
        items(habits) { h ->
            Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${h.emoji}  ${h.title}", modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                        Switch(checked = h.enabled, onCheckedChange = { onEnabled(h, it) })
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Koszt dzienny: ${h.dailyCost} zł", modifier = Modifier.weight(1f), color = Muted)
                        TextButton(onClick = { editing = h; costText = h.dailyCost.toString() }) { Text("Zmień") }
                    }
                    val days = max(0L, (System.currentTimeMillis() - h.start) / 86400000L)
                    Text("Szacowane oszczędności: ${days * h.dailyCost} zł", color = Green)
                }
            }
        }
        item {
            Text("Dane są przechowywane lokalnie na tym urządzeniu. Odinstalowanie aplikacji może usunąć zapisane dane.", color = Muted, fontSize = 12.sp)
            Text("Zegar Trzeźwości • wersja 2.0", color = Muted, fontSize = 12.sp)
        }
    }
    editing?.let { h ->
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text("Dzienny koszt: ${h.title}") },
            text = {
                OutlinedTextField(value = costText, onValueChange = { costText = it.filter(Char::isDigit).take(5) }, label = { Text("Kwota w zł") }, singleLine = true)
            },
            confirmButton = {
                TextButton(onClick = { onCost(h, costText.toIntOrNull() ?: 0); editing = null }) { Text("Zapisz") }
            },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("Anuluj") } }
        )
    }
}
